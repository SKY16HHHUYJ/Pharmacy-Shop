﻿public class YourEntity
{
}