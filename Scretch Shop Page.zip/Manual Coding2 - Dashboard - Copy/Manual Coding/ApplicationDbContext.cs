﻿internal class ApplicationDbContext
{
    public object Users { get; internal set; }
}